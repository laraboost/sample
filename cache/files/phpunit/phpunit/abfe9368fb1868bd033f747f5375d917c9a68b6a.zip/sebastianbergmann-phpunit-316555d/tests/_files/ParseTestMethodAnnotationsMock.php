<?php
/**
 * @theClassAnnotation
 */
class ParseTestMethodAnnotationsMock
{
    use ParseTestMethodAnnotationsTrait;
}

/**
 * @theTraitAnnotation
 */
trait ParseTestMethodAnnotationsTrait
{
}
