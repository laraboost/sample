<?php

namespace Laravel\Horizon\Events;

class JobPushed extends RedisEvent
{
    //
}
